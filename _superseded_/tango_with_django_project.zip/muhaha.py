fp = r'C:\Users\sendh\Google Drive\tango_with_django_project\templates\rango\add_category.html'

new_content = ''
with open(fp, 'r') as f:
    for line in f:
        if line.startswith('www.tangowithdjango.comForms'): continue
        new_content += ' '.join(line.split(' ')[1:])

with open(fp, 'w') as f:
    f.write(new_content)
