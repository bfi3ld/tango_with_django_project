import subprocess

subprocess.call('python manage.py runserver localhost:8000')